<?php
$link = mysqli_connect('localhost','root','','timetable');
if($link == false){
    echo 'Ошибка подключения';
    echo mysqli_connect_error();
    echo '<br>';
} else {
    echo 'Вы успешно подключились к БД';
    echo '<br>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <ul>
        <li><a href="index.php">Главное</a></li>
        <li><a href="index.php?module=addlesson">Предметы</a></li>
    </ul>
    <?php
        if(isset($_GET['module'])){
            $module = $_GET['module'];
        } else {
            $module = 'index';
        }
        switch($module){
            case 'index':
                include 'inc/main.php';
                break;
            case 'addlesson':
                include 'inc/addlesson.php';
                break;
            case 'changelesson':
                include 'inc/changelesson.php';
                break;
            default:
                include 'inc/main.php';
        }
    ?>
</body>
</html>