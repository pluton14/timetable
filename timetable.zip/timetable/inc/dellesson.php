<?php
    if(delLessons($link, $_GET['id'])){
        echo 'Успешно удалено';
    } else {
        echo 'Ошибка удаления';
    }
?>