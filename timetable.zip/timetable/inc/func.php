<?php
    function connectDB($host, $user, $pass, $db){
        $link = mysqli_connect($host,$user,$pass,$db);
        if($link == false){
            echo mysqli_connect_error();
            echo '<br>';
        } 
        return $link;
    }
    function getLessons($link){
        $sql = 'SELECT * FROM lessons';
        $res = mysqli_query($link, $sql);
        $rows = mysqli_fetch_all($res, MYSQLI_ASSOC);
        return $rows;
    }
    function addLessons($link){
        if(!empty($_POST['title'])){
            $title = $_POST['title'];
            $q = 'INSERT INTO lessons VALUES(NULL,"'.$title.'")';
            if(mysqli_query($link, $q)){
            } else {
                echo mysqli_error($link);
            }
        }
    }
    function changeLesson($link, $id, $title){
        $sql = 'UPDATE lessons SET title="'.$title.'" WHERE id='.$id;
        $res = mysqli_query($link, $sql);
        return $res;
    }
    function delLessons($link, $id){
        $sql = 'DELETE FROM lessons WHERE id='.$id;
        $res = mysqli_query($link, $sql);
        return $res;
    }
?>