<?php
    $sql = 'SELECT * FROM lessons';
    $res = mysqli_query($link, $sql);
    $rows = mysqli_fetch_all($res, MYSQLI_ASSOC);
    echo '<table border="1">';
    echo '<tr><th>id</th><th>Название</th></tr>';
    foreach($rows as $row){
        echo '<tr>';
        echo '<td>'.$row['id'].'</td><td>'.$row['name'].'</td>';
        echo '</tr>';
    }
?>
