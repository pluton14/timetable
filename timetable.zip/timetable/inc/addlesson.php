<?php
    addLessons($link);
    $rows = getLessons($link);
    echo '<table border="1">';
    echo '<tr><th>id</th><th>Название</th></tr>';
    foreach($rows as $row){
        echo '<tr>';
        echo '<td>'.$row['id'].'</td><td>'.$row['name'].'</td>';
        echo '<td><a href="index.php?module=dellesson&id='.$row['id'].'">Удалить</a></td>';
        echo '</tr>';
    }   

?>
<form method='post'>
    <input name='title'>
    <input type="submit" value='Добавить'>
</form>
